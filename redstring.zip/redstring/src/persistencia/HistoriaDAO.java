package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Historia;
import model.Localizacao;
import model.Personagem;
import model.Usuario;
import util.ConversaoDataUtil;

public class HistoriaDAO {
	private ConexaoMYSQL conexao;

	public HistoriaDAO() {
		this.conexao = new ConexaoMYSQL();
	}

	// TESTADO
	public Historia adicionarHist(Historia historia) {
		this.conexao.abrirConexao();

		String sqlInsert = "INSERT INTO Historia VALUES(null, ?, ?, ?, ?);";

		try {

			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert,
					PreparedStatement.RETURN_GENERATED_KEYS);
			st.setString(1, historia.getTituloHist());
			st.setDate(2, ConversaoDataUtil.localDateToDate(historia.getDataHist())); // converter LocalDate em Date
			st.setString(3, historia.getDescHist());
			st.setLong(4, historia.getUsuario().getIdUsuario()); // editar mysql + banco para que idusuario seja
																	// obrigatorio
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if (rs.next()) {
					historia.setIdHistoria(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return historia;

	}

	// editar historia TESTADO
	public void editarHist(Historia historia) {
		this.conexao.abrirConexao();

		String sqlUpdate = "UPDATE Historia SET titulo_hist = ?, desc_hist = ? WHERE id_hist = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, historia.getTituloHist());
			st.setString(2, historia.getDescHist());
			st.setLong(3,  historia.getIdHistoria());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally { // se o preparedstatement funcionar ou não, o finally vai ser executado

			// fechar conexao
			this.conexao.fecharConexao();
		}
	}

	// excluir historia TESTADO
	public void excluirHist(Historia historia) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Historia WHERE id_hist = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, historia.getIdHistoria());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

	}
	
	// exclue todas as histórias desse usuário
	public void excluirHistUser(Usuario user) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Historia WHERE id_usuario = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, user.getIdUsuario());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// busca por id TESTADO !:)
	public Historia buscaIdHist(long idHistoria) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Historia WHERE id_hist = ?";
		Historia historia = null; // se o if statement der falso (não existir dados nesse id) ele retorna null no
									// final

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setLong(1, idHistoria);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				historia = new Historia();
				UsuarioDAO usuarioDAO = new UsuarioDAO();

				historia.setIdHistoria(resSet.getLong("id_hist"));
				historia.setTituloHist(resSet.getString("titulo_hist"));
				// historia.setDataHist(ConversaoDataUtil.dateToLocalDate(resSet.getDate("data_hist")));
				historia.setDataHist(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_hist")));
				historia.setDescHist(resSet.getString("desc_hist"));
				historia.setUsuario(usuarioDAO.buscaIdUsuario(resSet.getLong("id_usuario")));

				// ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_hist"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return historia;
	}

	// busca por todas as historias de um user TESTADO
	public ArrayList<Historia> buscaPorUser(Usuario usuario) {
		conexao.abrirConexao();
		ArrayList<Historia> historias = new ArrayList<Historia>();

		String sqlQueryTodos = "SELECT * FROM Historia WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, usuario.getIdUsuario());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				Historia historia = new Historia();
				UsuarioDAO uDAO = new UsuarioDAO();

				historia.setIdHistoria(resSet.getLong("id_hist"));
				historia.setTituloHist(resSet.getString("titulo_hist"));
				historia.setDataHist(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_hist")));
				historia.setDescHist(resSet.getString("desc_hist"));
				historia.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));

				historias.add(historia);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return historias;
	}

	// busca pelo titulo da historia TESTADO
	public Historia buscaTitulo(String tituloHist) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Historia WHERE titulo_hist = ?";
		Historia historia = null; // se o if statement der falso (não existir dados nesse id) ele retorna null no
									// final

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setString(1, tituloHist);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				historia = new Historia();
				UsuarioDAO usuarioDAO = new UsuarioDAO();
				historia.setIdHistoria(resSet.getLong("id_hist"));
				historia.setTituloHist(resSet.getString("titulo_hist"));
				historia.setDataHist(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_hist")));
				historia.setDescHist(resSet.getString("desc_hist"));
				historia.setUsuario(usuarioDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return historia;
	}

	// busca por todos personagens daquela historia TESTADO
	public ArrayList<Personagem> buscaTodosPerso(Historia historia) {
		conexao.abrirConexao();
		ArrayList<Personagem> personagens = new ArrayList<Personagem>();

		String sqlQueryTodos = "SELECT * FROM Personagem WHERE id_hist = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, historia.getIdHistoria());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) { // ao invés de testar uma vez, o while testa todas as vezes que percorrer,
									// converte e adiciona na lista.quando o resSet for falso, cai pra fora
				Personagem personagem = new Personagem();
				UsuarioDAO uDAO = new UsuarioDAO();

				personagem.setIdPerso(resSet.getLong("id_perso"));
				personagem.setNomePerso(resSet.getString("nome_perso"));
				personagem.setDescPerso(resSet.getString("desc_perso"));
				personagem.setAparenciaPerso(resSet.getString("aparencia_perso"));
				personagem.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				personagem.setHistoria(historia);

				personagens.add(personagem);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return personagens;
	}

	// NT
	public ArrayList<Localizacao> buscaTodosLocais(Historia historia) {
		conexao.abrirConexao();
		ArrayList<Localizacao> locais = new ArrayList<Localizacao>();

		String sqlQueryTodos = "SELECT * FROM Localizacao WHERE id_hist = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, historia.getIdHistoria());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				Localizacao local = new Localizacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();

				local.setIdLocal(resSet.getLong("id_local"));
				local.setTituloLocal(resSet.getString("titulo_local"));
				local.setDescLocal(resSet.getString("desc_local"));
				local.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				local.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));

				locais.add(local);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return locais;
	}

}

package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.LocalPersona;
import model.Localizacao;
import model.Personagem;
import model.Usuario;

public class LocalPersonaDAO {
	private ConexaoMYSQL conexao;

	public LocalPersonaDAO() {
		conexao = new ConexaoMYSQL();
	}

	// TESTADO not the regenerated keys
	public LocalPersona adicionarLocalRel(LocalPersona localPer) {
		this.conexao.abrirConexao();

		String sqlInsert = "INSERT INTO Local_persona VALUES(null, ?, ?);";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert,
					PreparedStatement.RETURN_GENERATED_KEYS);
			st.setLong(1, localPer.getLocal().getIdLocal());
			st.setLong(2, localPer.getPersonagem().getIdPerso());
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if (rs.next()) {
					localPer.setIdLocalPersona(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return localPer;
	}

	// TESTADO
	public void excluirLocalRel(LocalPersona locRel) {
		conexao.abrirConexao();

		String sql = "DELETE FROM Local_persona WHERE id_local_persona = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setLong(1, locRel.getIdLocalPersona());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	public void excluirLocalRelUser(Usuario user) {
		PersonagemDAO pDAO = new PersonagemDAO();
		ArrayList<Personagem> personagens = pDAO.buscaPorUser(user);

		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Local_persona WHERE id_perso = ?";
		try {
			for (int i = 0; i < personagens.size(); i++) {
				PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
				st.setLong(1, personagens.get(i).getIdPerso());
				st.executeUpdate();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public LocalPersona buscaIdLoPe(Long localPerId) {
		conexao.abrirConexao();

		String sqlQuery = "SELECT * FROM Local_persona WHERE id_local_persona = ?";

		LocalPersona locPer = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQuery);
			st.setLong(1, localPerId);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				locPer = new LocalPersona();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				locPer.setIdLocalPersona(resSet.getLong("id_local_persona"));
				locPer.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				locPer.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return locPer;
	}

	// TESTADO
	public ArrayList<Localizacao> buscaLocais(Personagem personagem) {
		conexao.abrirConexao();
		ArrayList<Localizacao> locais = new ArrayList<Localizacao>();

		String sqlQueryTodos = "SELECT * FROM Local_persona WHERE id_perso = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, personagem.getIdPerso());

			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				LocalizacaoDAO lDAO = new LocalizacaoDAO();
				Localizacao local;

				local = lDAO.buscarIdLocal(resSet.getLong("id_local"));

				locais.add(local);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return locais;
	}

	// TESTADO
	public ArrayList<Personagem> buscaPersonagens(Localizacao local) {
		conexao.abrirConexao();
		ArrayList<Personagem> personagens = new ArrayList<Personagem>();

		String sqlQueryTodos = "SELECT * FROM Local_persona WHERE id_local = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, local.getIdLocal());

			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				PersonagemDAO pDAO = new PersonagemDAO();
				Personagem personagem;

				personagem = pDAO.buscaIdPerso((resSet.getLong("id_perso")));

				personagens.add(personagem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return personagens;
	}

}

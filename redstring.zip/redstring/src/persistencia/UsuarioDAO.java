package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Usuario;

public class UsuarioDAO {

	private ConexaoMYSQL conexao;

	public UsuarioDAO() {
		this.conexao = new ConexaoMYSQL();
	}

	// adicionar usuario TESTADO
	public Usuario adicionarUser(Usuario usuario) {
		this.conexao.abrirConexao();

		String sqlInsert = "INSERT INTO Usuario VALUES(null, ?, ?, ?);";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert, PreparedStatement.RETURN_GENERATED_KEYS);
			st.setString(1, usuario.getUsername());
			st.setString(2, usuario.getEmail());
			st.setString(3, usuario.getSenha());
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if(rs.next()) {
					usuario.setIdUsuario(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return usuario;
	}

	// metodo editar usuario TESTADO
	public void editarUser(Usuario usuario) {
		this.conexao.abrirConexao();

		String sqlUpdate = "UPDATE Usuario SET username = ?, email = ?, senha = ? WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, usuario.getUsername());
			st.setString(2, usuario.getEmail());
			st.setString(3, usuario.getSenha());
			st.setLong(4, usuario.getIdUsuario());
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally { 
			this.conexao.fecharConexao();
		}
	}

	// metodo excluir do banco TESTADO
	public void excluirUser(Usuario usuario) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Usuario WHERE id_usuario = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, usuario.getIdUsuario());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// metodo busca por ID TESTADO
	public Usuario buscaIdUsuario(long idUsuario) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Usuario WHERE id_usuario = ?";
		Usuario usuario = null; 
		
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setLong(1, idUsuario);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) { 
				usuario = new Usuario();
				
				usuario.setIdUsuario(resSet.getLong("id_usuario")); 
				usuario.setUsername(resSet.getString("username"));
				usuario.setEmail(resSet.getString("email"));
				usuario.setSenha(resSet.getString("senha"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return usuario;
	}

	// buscar por todos TESTADO
	public ArrayList<Usuario> buscaTodos() {
		conexao.abrirConexao();
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();

		String sqlQueryTodos = "SELECT * FROM Usuario";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) { // ao invés de testar uma vez, o while testa todas as vezes que percorrer,
									// converte e adiciona na lista.quando o resSet for falso, cai pra fora
				Usuario usuario = new Usuario();
				usuario.setIdUsuario(resSet.getLong("id_usuario"));
				usuario.setUsername(resSet.getString("username"));
				usuario.setEmail(resSet.getString("email"));
				usuario.setSenha(resSet.getString("senha"));

				usuarios.add(usuario);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return usuarios;
	}

	// busca por email e senha TESTADO!!!!!
	public Usuario buscaLogin(String email, String senha) {
		this.conexao.abrirConexao();
		Usuario usuario = new Usuario();

		String sqlQueryLogin = "SELECT * FROM Usuario WHERE email = ? AND senha = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryLogin);
			st.setString(1, email);
			st.setString(2, senha);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				usuario.setIdUsuario(resSet.getLong("id_usuario"));
				usuario.setUsername(resSet.getString("username"));
				usuario.setEmail(resSet.getString("email"));
				usuario.setSenha(resSet.getString("senha"));
			} else {
				usuario = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return usuario;
	}

}

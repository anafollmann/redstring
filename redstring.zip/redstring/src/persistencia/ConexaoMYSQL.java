package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMYSQL {
	private String ip;
	private String porta;
	private String login;
	private String senha;
	private String nomeBanco;
	
	private Connection conexao;
	
	public ConexaoMYSQL() {
		this.ip = BancoConfig.IP;
		this.porta = BancoConfig.PORTA;
		this.login = BancoConfig.LOGIN;
		this.senha = BancoConfig.SENHA;
		this.nomeBanco = BancoConfig.NOME_BANCO;
	}
	
	public ConexaoMYSQL(String ip, String porta, String login, String senha, String nomeBanco) {
		this.ip = ip;
		this.porta = porta;
		this.login = login;
		this.senha = senha;
		this.nomeBanco = nomeBanco;
	}

	// metodo para abrir conexao com banco de dados
	public void abrirConexao() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String endereco = "jdbc:mysql://" + this.ip + ":" + this.porta + "/" + this.nomeBanco;
			
			this.conexao = DriverManager.getConnection(endereco, this.login, this.senha);
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	// get conexao pro prepared statement
	public Connection getConexao() {
		return conexao;
	}
	
	// metodo para fechar conexao com bando de dados
	public void fecharConexao() {
		try {
			if (!conexao.isClosed()) {
				this.conexao.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
}

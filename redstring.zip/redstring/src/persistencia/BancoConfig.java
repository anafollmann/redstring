package persistencia;

public class BancoConfig {
	public static final String IP = "localhost";
    public static final String PORTA = "3306";
	public static final String LOGIN = "root";
	public static final String SENHA = "171277";
	public static final String NOME_BANCO = "redstring";

			
}

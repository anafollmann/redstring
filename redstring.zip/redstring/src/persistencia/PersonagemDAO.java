package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Personagem;
import model.Usuario;

public class PersonagemDAO {

	private ConexaoMYSQL conexao;

	public PersonagemDAO() {
		this.conexao = new ConexaoMYSQL();
	}

	// adicionar personagem TESTADO
	public Personagem adicionarPerso(Personagem personagem) {
		this.conexao.abrirConexao();

		String sqlInsert;
		if (personagem.getHistoria() == null) { // se nao for relacionado com uma historia
			sqlInsert = "INSERT INTO Personagem VALUES(null, ?, ?, ?, ?, null);";
		} else { // se for
			sqlInsert = "INSERT INTO Personagem VALUES(null, ?, ?, ?, ?, ?);";
		}

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert,
					PreparedStatement.RETURN_GENERATED_KEYS);
			st.setString(1, personagem.getNomePerso());
			st.setString(2, personagem.getDescPerso());
			st.setString(3, personagem.getAparenciaPerso());
			st.setLong(4, personagem.getUsuario().getIdUsuario());
			if (personagem.getHistoria() != null) {
				st.setLong(5, personagem.getHistoria().getIdHistoria());
			}

			int afetados = st.executeUpdate();
			if (afetados > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if (rs.next()) {
					personagem.setIdPerso(rs.getLong(1));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return personagem;
	}

	// editar personagem TESTADO
	public void editarPersonagem(Personagem personagem) {
		this.conexao.abrirConexao();

		String sqlUpdate = "UPDATE Personagem SET nome_perso = ?, desc_perso = ?, aparencia_perso = ? WHERE id_perso = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, personagem.getNomePerso());
			st.setString(2, personagem.getDescPerso());
			st.setString(3, personagem.getAparenciaPerso());
			st.setLong(4, personagem.getIdPerso());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// metodo excluir do banco TESTADO
	public void excluirPersonagem(Personagem personagem) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Personagem WHERE id_perso = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, personagem.getIdPerso());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// excluir de acordo com o usuario
	public void excluirPersonagemUser(Usuario user) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Personagem WHERE id_usuario = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, user.getIdUsuario());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// buscar por id de personagem TESTADO
	public Personagem buscaIdPerso(long idPerso) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Personagem WHERE id_perso = ?";
		Personagem personagem = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setLong(1, idPerso);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				personagem = new Personagem();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				personagem.setIdPerso(resSet.getLong("id_perso"));
				personagem.setNomePerso(resSet.getString("nome_perso"));
				personagem.setDescPerso(resSet.getString("desc_perso"));
				personagem.setAparenciaPerso(resSet.getString("aparencia_perso"));
				personagem.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				personagem.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return personagem;
	}

	// busca por usuario retorna todos os personagens desse usuario TESTADO
	public ArrayList<Personagem> buscaPorUser(Usuario usuario) {
		conexao.abrirConexao();
		ArrayList<Personagem> personagens = new ArrayList<Personagem>();

		String sqlQueryTodos = "SELECT * FROM Personagem WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, usuario.getIdUsuario());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				Personagem personagem = new Personagem();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();

				personagem.setIdPerso(resSet.getLong("id_perso"));
				personagem.setNomePerso(resSet.getString("nome_perso"));
				personagem.setDescPerso(resSet.getString("desc_perso"));
				personagem.setAparenciaPerso(resSet.getString("aparencia_perso"));
				personagem.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				personagem.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));

				personagens.add(personagem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return personagens;
	}

	// search method where it searches by a keyword in name, like it returns all
	// characters with that first name/lastname the user gave
	// busca pelo nome exato dado pelo usuário (se o metodo acima não for possível
	// TESTADO
	public Personagem buscaNome(String nome) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Personagem WHERE nome_perso = ?";
		Personagem personagem = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setString(1, nome);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				personagem = new Personagem();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				personagem.setIdPerso(resSet.getLong("id_perso"));
				personagem.setNomePerso(resSet.getString("nome_perso"));
				personagem.setDescPerso(resSet.getString("desc_perso"));
				personagem.setAparenciaPerso(resSet.getString("aparencia_perso"));
				personagem.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				personagem.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return personagem;
	}

}

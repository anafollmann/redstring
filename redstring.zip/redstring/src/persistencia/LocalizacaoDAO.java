package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Localizacao;
import model.Usuario;

public class LocalizacaoDAO {

	private ConexaoMYSQL conexao;

	public LocalizacaoDAO() {
		conexao = new ConexaoMYSQL();
	}

	// TESTADO not the regenerated keys
	public Localizacao adicionarLocal(Localizacao local) {
		this.conexao.abrirConexao();

		String sqlInsert;
		if (local.getHistoria() == null) { // se nao for relacionado com uma historia
			sqlInsert = "INSERT INTO Localizacao VALUES(null, ?, ?, ?, null);";
		} else { // se for
			sqlInsert = "INSERT INTO Localizacao VALUES(null, ?, ?, ?, ?);";
		}

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert,
					PreparedStatement.RETURN_GENERATED_KEYS);
			st.setString(1, local.getTituloLocal());
			st.setString(2, local.getDescLocal());
			st.setLong(3, local.getUsuario().getIdUsuario());
			if (local.getHistoria() != null) {
				st.setLong(4, local.getHistoria().getIdHistoria());
			}
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if (rs.next()) {
					local.setIdLocal(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return local;
	}

	// TESTADO
	public void editarLocal(Localizacao local) {
		this.conexao.abrirConexao();

		String sqlUpdate = "UPDATE Localizacao SET titulo_local = ?, desc_local = ? WHERE id_local = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, local.getTituloLocal());
			st.setString(2, local.getDescLocal());
			st.setLong(3, local.getIdLocal());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public void excluirLocal(Localizacao local) {
		conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Localizacao WHERE id_local = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, local.getIdLocal());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	public void excluirLocalUser(Usuario user) {
		conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Localizacao WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, user.getIdUsuario());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public Localizacao buscarIdLocal(long idLocal) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Localizacao WHERE id_local = ?";
		Localizacao local = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setLong(1, idLocal);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				local = new Localizacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				local.setIdLocal(idLocal);
				local.setTituloLocal(resSet.getString("titulo_local"));
				local.setDescLocal(resSet.getString("desc_local"));
				local.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				local.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return local;
	}

	// TESTADO
	public Localizacao buscaPorNome(String nomeLocal) {
		conexao.abrirConexao();

		String sqlQuery = "SELECT * FROM Localizacao WHERE titulo_local = ?";
		Localizacao local = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQuery);
			st.setString(1, nomeLocal);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				local = new Localizacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				local.setIdLocal(resSet.getLong("id_local"));
				local.setTituloLocal(resSet.getString("titulo_local"));
				local.setDescLocal(resSet.getString("desc_local"));
				local.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				local.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return local;

	}

	// TESTADO
	public ArrayList<Localizacao> buscaPorUser(Usuario usuario) {
		conexao.abrirConexao();
		ArrayList<Localizacao> locais = new ArrayList<Localizacao>();

		String sqlQueryTodos = "SELECT * FROM Localizacao WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, usuario.getIdUsuario());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				Localizacao local = new Localizacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();

				local.setIdLocal(resSet.getLong("id_local"));
				local.setTituloLocal(resSet.getString("titulo_local"));
				local.setDescLocal(resSet.getString("desc_local"));
				local.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				local.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));

				locais.add(local);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return locais;
	}

}

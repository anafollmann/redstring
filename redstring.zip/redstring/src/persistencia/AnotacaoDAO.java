package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import model.Anotacao;
import model.Historia;
import model.Localizacao;
import model.Personagem;
import model.Usuario;
import util.ConversaoDataUtil;

public class AnotacaoDAO {
	private ConexaoMYSQL conexao;

	public AnotacaoDAO() {
		conexao = new ConexaoMYSQL();
	}

	// TESTADO rel perso, TESTADO rel historia, TESTADO rel local
	public Anotacao adicionarNota(Anotacao nota, int relacao) {
		conexao.abrirConexao();

		String sqlInsert = "INSERT INTO Anotação VALUES(0, ?, ?, ?, ?, ?, ?, ?)";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert, PreparedStatement.RETURN_GENERATED_KEYS);

			st.setString(1, nota.getTituloNota());
			st.setString(2, nota.getConteudo());
			st.setDate(3, ConversaoDataUtil.localDateToDate(nota.getDataNota()));
			st.setLong(4, nota.getUsuario().getIdUsuario());

			if (relacao == 1) { // relacionamento historia
				st.setLong(5, nota.getHistoria().getIdHistoria());
				st.setString(6, null);
				st.setString(7, null);

			} else if (relacao == 2) { // relacionamento personagem
				st.setString(5, null);
				st.setString(6, null);
				st.setLong(7, nota.getPersonagem().getIdPerso());

			} else if (relacao == 3) { // relacionamento localizacao
				st.setString(5, null);
				st.setLong(6, nota.getLocal().getIdLocal());
				st.setString(7, null);

			}
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if(rs.next()) {
					nota.setIdNota(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return nota;
	}

	// TESTADO
	public void editarNota(Anotacao nota) {
		conexao.abrirConexao();

		String sqlUpdate = "UPDATE Anotação SET titulo_nota = ?, conteudo = ? WHERE id_nota = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, nota.getTituloNota());
			st.setString(2, nota.getConteudo());
			st.setLong(3,  nota.getIdNota());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public void excluirNota(Anotacao nota) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Anotação WHERE id_nota = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, nota.getIdNota());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			this.conexao.fecharConexao();
		}

	}
	
	public void excluirNotaUser(Usuario user) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Anotação WHERE id_usuario = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, user.getIdUsuario());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			this.conexao.fecharConexao();
		}

	}


	// TESTADO
	public Anotacao buscarIdNota(long idNota) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Anotação WHERE id_nota = ?";
		Anotacao nota = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setLong(1, idNota);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return nota;

	}

	// a query that parses through text? like you give key words and it parses
	// through conteudo
	// one for by stories, characters and places, by date as well?

	// TESTADO
	public Anotacao buscarNomeNota(String nome) {
		this.conexao.abrirConexao();

		String sqlQueryId = "SELECT * FROM Anotação WHERE titulo_nota = ?";
		Anotacao nota = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryId);
			st.setString(1, nome);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return nota;
	}

	// TESTADO
	public ArrayList<Anotacao> buscaPorUser(Usuario usuario) {
		conexao.abrirConexao();
		ArrayList<Anotacao> notas = new ArrayList<Anotacao>();

		String sqlQueryTodos = "SELECT * FROM Anotação WHERE id_usuario = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, usuario.getIdUsuario());
			ResultSet resSet = st.executeQuery();
			
			

			while (resSet.next()) {
				Anotacao nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

				notas.add(nota);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return notas;
	}

	// TESTADO
	public ArrayList<Anotacao> buscaPorHist(Historia historia) {
		conexao.abrirConexao();
		ArrayList<Anotacao> notas = new ArrayList<Anotacao>();

		String sqlQueryTodos = "SELECT * FROM Anotação WHERE id_hist = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, historia.getIdHistoria());
			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {
				Anotacao nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

				notas.add(nota);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return notas;
	}

	// TESTADO
	public ArrayList<Anotacao> buscaPorPerso(Personagem personagem) {
		conexao.abrirConexao();
		ArrayList<Anotacao> notas = new ArrayList<Anotacao>();

		String sqlQueryTodos = "SELECT * FROM Anotação WHERE id_perso = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, personagem.getIdPerso());
			ResultSet resSet = st.executeQuery();
			
			

			while (resSet.next()) {
				Anotacao nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

				notas.add(nota);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return notas;
	}

	// TESTADO
	public ArrayList<Anotacao> buscaPorLocal(Localizacao local) {
		conexao.abrirConexao();
		ArrayList<Anotacao> notas = new ArrayList<Anotacao>();

		String sqlQueryTodos = "SELECT * FROM Anotação WHERE id_local = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, local.getIdLocal());
			ResultSet resSet = st.executeQuery();
			
			

			while (resSet.next()) {
				Anotacao nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

				notas.add(nota);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return notas;
	}

	// LocalDate date = LocalDate.of(2023, 4, 14);

	// TESTADO puta processo pro usuario entrar uma data
	public ArrayList<Anotacao> buscaPorData(LocalDate data) {
		conexao.abrirConexao();
		ArrayList<Anotacao> notas = new ArrayList<Anotacao>();

		String sqlQueryTodos = "SELECT * FROM Anotação WHERE data_nota = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setDate(1, ConversaoDataUtil.localDateToDate(data));
			ResultSet resSet = st.executeQuery();
			
			

			while (resSet.next()) {
				Anotacao nota = new Anotacao();
				UsuarioDAO uDAO = new UsuarioDAO();
				HistoriaDAO hDAO = new HistoriaDAO();
				PersonagemDAO pDAO = new PersonagemDAO();
				LocalizacaoDAO lDAO = new LocalizacaoDAO();

				nota.setIdNota(resSet.getLong("id_nota"));
				nota.setTituloNota(resSet.getString("titulo_nota"));
				nota.setConteudo(resSet.getString("conteudo"));
				nota.setDataNota(ConversaoDataUtil.fromDateToLocalDate(resSet.getDate("data_nota")));
				nota.setUsuario(uDAO.buscaIdUsuario(resSet.getLong("id_usuario")));
				nota.setHistoria(hDAO.buscaIdHist(resSet.getLong("id_hist")));
				nota.setLocal(lDAO.buscarIdLocal(resSet.getLong("id_local")));
				nota.setPersonagem(pDAO.buscaIdPerso(resSet.getLong("id_perso")));

				notas.add(nota);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}

		return notas;
	}

}

package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.PersoPerso;
import model.Personagem;
import model.Usuario;

public class PersoPersoDAO {
	private ConexaoMYSQL conexao;

	public PersoPersoDAO() {
		conexao = new ConexaoMYSQL();
	}

	// TESTADO not regenerated keys
	public PersoPerso adicionarPRel(PersoPerso perRel) {
		this.conexao.abrirConexao();

		String sqlInsert = "INSERT INTO Perso_perso VALUES(null, ?, ?, ?);";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlInsert,
					PreparedStatement.RETURN_GENERATED_KEYS);
			st.setString(1, perRel.getRelTitulo());
			st.setLong(2, perRel.getPerso1().getIdPerso());
			st.setLong(3, perRel.getPerso2().getIdPerso());
			int afetado = st.executeUpdate();
			if (afetado > 0) {
				ResultSet rs = st.getGeneratedKeys();
				if (rs.next()) {
					perRel.setIdPersoPerso(rs.getLong(1));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return perRel;
	}

	// TESTADO
	public void editarPerPer(PersoPerso persoRel) {
		conexao.abrirConexao();

		String sqlUpdate = "UPDATE Perso_perso SET rel_titulo = ? WHERE id_perso_perso = ? ";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlUpdate);
			st.setString(1, persoRel.getRelTitulo());
			st.setLong(2, persoRel.getIdPersoPerso());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public void excluirRel(PersoPerso perRel) {
		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Perso_perso WHERE id_perso_perso = ?";
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
			st.setLong(1, perRel.getIdPersoPerso());
			st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	public void excluirRelUser(Usuario user) {

		PersonagemDAO pDAO = new PersonagemDAO();
		ArrayList<Personagem> personagens = pDAO.buscaPorUser(user);

		this.conexao.abrirConexao();

		String sqlDelete = "DELETE FROM Perso_perso WHERE id_perso = ? OR id_perso2 = ?";
		try {
			for (int i = 0; i < personagens.size(); i++) {
				PreparedStatement st = conexao.getConexao().prepareStatement(sqlDelete);
				st.setLong(1, personagens.get(i).getIdPerso());
				st.setLong(2, personagens.get(i).getIdPerso());
				st.executeUpdate();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
	}

	// TESTADO
	public PersoPerso buscaIdPRel(Long idPRel) {
		conexao.abrirConexao();

		String sqlQuery = "SELECT * FROM Perso_perso WHERE id_perso_perso = ?";

		PersoPerso perRel = null;

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQuery);
			st.setLong(1, idPRel);
			ResultSet resSet = st.executeQuery();

			if (resSet.next()) {
				perRel = new PersoPerso();
				PersonagemDAO pDAO = new PersonagemDAO();

				perRel.setIdPersoPerso(resSet.getLong("id_perso_perso"));
				perRel.setRelTitulo(resSet.getString("rel_titulo"));
				perRel.setPerso1(pDAO.buscaIdPerso(resSet.getLong("id_perso")));
				perRel.setPerso2(pDAO.buscaIdPerso(resSet.getLong("id_perso2")));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return perRel;
	}

	// TESTADO
	public ArrayList<PersoPerso> buscaPorPerso(Personagem personagem) {
		conexao.abrirConexao();
		ArrayList<PersoPerso> perRels = new ArrayList<PersoPerso>();

		String sqlQueryTodos = "SELECT * FROM Perso_perso WHERE id_perso = ? OR id_perso2 = ?";

		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sqlQueryTodos);
			st.setLong(1, personagem.getIdPerso());
			st.setLong(2, personagem.getIdPerso());

			ResultSet resSet = st.executeQuery();

			while (resSet.next()) {

				PersoPerso perRel = new PersoPerso();
				PersonagemDAO pDAO = new PersonagemDAO();

				perRel.setPerso1(pDAO.buscaIdPerso(resSet.getLong("id_perso")));
				perRel.setPerso2(pDAO.buscaIdPerso(resSet.getLong("id_perso2")));
				perRel.setRelTitulo(resSet.getString("rel_titulo"));

				perRels.add(perRel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.conexao.fecharConexao();
		}
		return perRels;
	}

}

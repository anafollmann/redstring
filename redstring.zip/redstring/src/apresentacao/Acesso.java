package apresentacao;

import java.util.ArrayList;
import java.util.Scanner;

import model.Usuario;
import model.Anotacao;
import persistencia.AnotacaoDAO;
import model.Historia;
import model.Localizacao;
import model.Personagem;
import persistencia.HistoriaDAO;
import persistencia.LocalizacaoDAO;
import persistencia.PersonagemDAO;
import persistencia.PersoPersoDAO;
import model.PersoPerso;
import persistencia.LocalPersonaDAO;

public class Acesso {

	HistoriaDAO hDAO = new HistoriaDAO();
	AnotacaoDAO aDAO = new AnotacaoDAO();
	Anotacao nota = new Anotacao();
	PersonagemDAO pDAO = new PersonagemDAO();
	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	LocalPersonaDAO lPDAO = new LocalPersonaDAO();
	Localizacao local = new Localizacao();
	Historia hist = new Historia();
	ArrayList<Anotacao> notas;
	Scanner kb = new Scanner(System.in);

	public void todasHist(Usuario user) {

		System.out.println("-> Histórias");
		ArrayList<Historia> historias;

		historias = hDAO.buscaPorUser(user);

		if (historias == null) {
			System.out.println("Você não tem nenhuma história.");
		} else {
			for (int x = 0; x < historias.size(); x++) {
				hist = historias.get(x);

				System.out.println(
						"\n" + hist.getTituloHist() + "\n" + hist.getDataHist() + "\n" + hist.getDescHist() + "\n");
			}
		}

	}

	public void buscaNomeHist(Usuario user) {
		System.out.println("-> Busca por nome:");

		System.out.println("Nome da história:");
		hist = hDAO.buscaTitulo(kb.nextLine());

		if (hist == null || hist.getUsuario().getIdUsuario() != user.getIdUsuario()) {
			System.out.println("Você não tem nenhuma história nesse nome.");
		} else {
			System.out.println(
					"\n" + hist.getTituloHist() + "\n" + hist.getDataHist() + "\n" + hist.getDescHist() + "\n");

			System.out.println("-> Anotações associadas");
			notas = aDAO.buscaPorHist(hist);

			if (notas == null) {
				System.out.println("Nenhuma anotação relacionada a essa história.");
			} else {

				for (int x = 0; x < notas.size(); x++) {
					nota = notas.get(x);

					System.out.println(
							"\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo() + "\n");
				}
			}

			System.out.println("-> Personagens associados");
			ArrayList<Personagem> personagens;

			personagens = hDAO.buscaTodosPerso(hist);

			if (personagens == null) {
				System.out.println("Você não tem nenhum peronagem associado.");
			} else {
				for (int x = 0; x < personagens.size(); x++) {
					Personagem personagem = personagens.get(x);

					System.out.println("\n" + personagem.getNomePerso() + "\n" + personagem.getAparenciaPerso() + "\n"
							+ personagem.getDescPerso() + "\n");
				}
			}

			System.out.println("-> Locais associados");
			ArrayList<Localizacao> locais;

			locais = hDAO.buscaTodosLocais(hist);

			if (locais == null) {
				System.out.println("Você não tem nenhum local associado.");
			} else {
				for (int x = 0; x < locais.size(); x++) {
					Localizacao local = locais.get(x);

					System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());
				}
			}

		}

	}

	public void todosPerso(Usuario user) {

		System.out.println("-> Personagens");
		ArrayList<Personagem> personagens;

		personagens = pDAO.buscaPorUser(user);

		if (personagens == null) {
			System.out.println("Você não tem nenhum personagem.");
		} else {
			for (int x = 0; x < personagens.size(); x++) {
				Personagem personagem = personagens.get(x);

				System.out.println("\n" + personagem.getNomePerso() + "\n" + personagem.getAparenciaPerso() + "\n"
						+ personagem.getDescPerso());
				if (personagem.getHistoria() != null) {
					System.out.println(personagem.getHistoria().getTituloHist());
				}
			}
		}

	}

	public void buscaNomePerso(Usuario user) {
		System.out.println("-> Busca por nome:");

		System.out.println("Nome do personagem:");
		Personagem personagem = pDAO.buscaNome(kb.nextLine());

		if (personagem == null || personagem.getUsuario().getIdUsuario() != user.getIdUsuario()) {
			System.out.println("Você não tem nenhum personagem nesse nome.");
		} else {
			System.out.println("\n" + personagem.getNomePerso() + "\n" + personagem.getAparenciaPerso() + "\n"
					+ personagem.getDescPerso());
			if (personagem.getHistoria() != null) {
				System.out.println(personagem.getHistoria().getTituloHist());
			}

			System.out.println("-> Anotações associadas");
			notas = aDAO.buscaPorPerso(personagem);

			if (notas == null) {
				System.out.println("Nenhuma anotação relacionada a esse personagem.");
			} else {

				for (int x = 0; x < notas.size(); x++) {
					nota = notas.get(x);

					System.out.println(
							"\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo() + "\n");
				}
			}

			System.out.println("-> Personagens relacionados");
			PersoPersoDAO relDAO = new PersoPersoDAO();

			ArrayList<PersoPerso> perRels = relDAO.buscaPorPerso(personagem);

			if (perRels == null) {
				System.out.println("Nenhuma personagem relacionado a esse personagem.");
			} else {
				for (int x = 0; x < perRels.size(); x++) {
					PersoPerso perRel = perRels.get(x);

					System.out.println("\n" + perRel.getPerso1().getNomePerso() + " e "
							+ perRel.getPerso2().getNomePerso() + "\n" + perRel.getRelTitulo());
				}
			}

			System.out.println("-> Locais relacionados");
			ArrayList<Localizacao> locPer = lPDAO.buscaLocais(personagem);

			if (locPer == null) {
				System.out.println("Você não tem nenhum local associado.");
			} else {
				for (int x = 0; x < locPer.size(); x++) {
					Localizacao local = locPer.get(x);

					System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());
				}
			}
		}
	}

	public void todosLocais(Usuario user) {

		System.out.println("-> Locais");
		ArrayList<Localizacao> locais;

		locais = lDAO.buscaPorUser(user);

		if (locais == null) {
			System.out.println("Você não tem nenhum local.");
		} else {
			for (int x = 0; x < locais.size(); x++) {
				Localizacao local = locais.get(x);

				System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());
				if (local.getHistoria() != null) {
					System.out.println(local.getHistoria().getTituloHist());
				}

			}
		}
	}

	public void buscaNomeLocal(Usuario user) {
		System.out.println("-> Busca por nome:");

		System.out.println("Nome do local:");
		Localizacao local = lDAO.buscaPorNome((kb.nextLine()));

		if (local == null || local.getUsuario().getIdUsuario() != user.getIdUsuario()) {
			System.out.println("Você não tem nenhum local nesse nome.");
		} else {
			System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());
			if (local.getHistoria() != null) {
				System.out.println(local.getHistoria().getTituloHist());
			}

			System.out.println("-> Anotações associadas");
			notas = aDAO.buscaPorLocal(local);

			if (notas == null) {
				System.out.println("Nenhuma anotação relacionada a esse personagem.");
			} else {
				for (int x = 0; x < notas.size(); x++) {
					nota = notas.get(x);

					System.out.println(
							"\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo() + "\n");
				}
			}

			System.out.println("-> Personagens relacionados");
			ArrayList<Personagem> locPer = lPDAO.buscaPersonagens(local);

			if (locPer == null) {
				System.out.println("Você não tem nenhum personagem associado.");
			} else {
				for (int x = 0; x < locPer.size(); x++) {
					Personagem personagem = locPer.get(x);

					System.out.println("\n" + personagem.getNomePerso() + "\n");
				}
			}
		}
	}

	public void todasNotas(Usuario user) {

		System.out.println("-> Anotações");
		ArrayList<Anotacao> notas;

		notas = aDAO.buscaPorUser(user);

		if (notas == null) {
			System.out.println("Você não tem nenhuma anotação.");
		} else {
			for (int x = 0; x < notas.size(); x++) {
				nota = notas.get(x);

				System.out.println(
						"\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo() + "\n");
			}
		}

	}

	public void buscaNomeNota(Usuario user) {
		System.out.println("-> Busca por nome:");

		System.out.println("Título da anotação:");
		Anotacao nota = aDAO.buscarNomeNota(kb.next());

		if (nota == null || nota.getUsuario().getIdUsuario() != user.getIdUsuario()) {
			System.out.println("Você não tem nenhuma anotação nesse nome.");
		} else {
			if (nota.getPersonagem() != null) {
				System.out.println("-> Personagem relacionado:" + nota.getPersonagem().getNomePerso());
			} else if (nota.getHistoria() != null) {
				System.out.println("-> História relacionado:" + nota.getHistoria().getTituloHist());
			} else if (nota.getLocal() != null) {
				System.out.println("-> Local relacionado: " + nota.getLocal().getTituloLocal());
			}

			System.out.println("\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo());

		}

	}

}

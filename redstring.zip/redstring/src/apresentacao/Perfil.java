package apresentacao;

import java.util.Scanner;

import model.Usuario;
import persistencia.AnotacaoDAO;
import persistencia.HistoriaDAO;
import persistencia.LocalPersonaDAO;
import persistencia.LocalizacaoDAO;
import persistencia.PersoPersoDAO;
import persistencia.PersonagemDAO;
import persistencia.UsuarioDAO;

public class Perfil {

	Scanner kb = new Scanner(System.in);
	int entrada = 0;
	Usuario user = new Usuario();
	UsuarioDAO uDAO = new UsuarioDAO();
	HistoriaDAO hDAO = new HistoriaDAO();
	PersonagemDAO pDAO = new PersonagemDAO();
	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	AnotacaoDAO aDAO = new AnotacaoDAO();
	PersoPersoDAO relDAO = new PersoPersoDAO();
	LocalPersonaDAO lPDAO = new LocalPersonaDAO();

	public Usuario cadastrar() {
		System.out.println("-> Cadastro: \n");

		boolean confirm = false;
		while (!confirm) {
			System.out.println("Username:");

			user.setUsername(kb.next());

			System.out.println("Email:");

			user.setEmail(kb.next());

			System.out.println("Senha (mínimo 6 digitos):");
			user.setSenha("");
			while (user.getSenha().length() < 6) {
				user.setSenha(kb.next());

				if (user.getSenha().length() < 6) {
					System.out.println("Por favor, digite uma senha com, no mínimo, 6 digitos.");
				}
			}

			System.out.println("Confirme seus dados: \n" + "Username: " + user.getUsername() + "\n" + "Email: "
					+ user.getEmail() + "\n" + "Senha: " + user.getSenha());

			System.out.println("1. Confirmar dados. \n2. Editar dados");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				user = uDAO.adicionarUser(user);
				if (user.getIdUsuario() == 0) {
					System.out.println("Aconteceu um erro em seu cadastro, por favor tente novamente.");
				} else {
					confirm = true;
				}
			}
		}

		return user;
	}

	public Usuario login() {
		System.out.println("-> Login: \n");

		boolean find = false;
		while (!find) {
			System.out.println("Email:");
			String email = kb.next();

			System.out.println("Senha:");
			String senha = kb.next();

			user = uDAO.buscaLogin(email, senha);

			if (user == null) {
				System.out.println("Nenhum usuário com esses dados foi encontrado.");
			} else {
				find = true;
			}
		}

		return user;
	}

	public Usuario editar(Usuario user) {
		System.out.println("-> Editar perfil:\n");

		System.out.println("Novo username:");
		user.setUsername(kb.next());

		System.out.println("Novo email:");
		user.setEmail(kb.next());

		System.out.println("Nova senha:");
		user.setSenha(kb.next());

		uDAO.editarUser(user);

		return user;
	}

	public boolean excluir(Usuario user) {
		System.out.println("-> Excluir conta");

		System.out.println(
				"Tem certeza que deseja deletar sua conta? Você perderá todas as suas criações. \n1. Sim. \n2. Não, quero permanecer.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) {

			relDAO.excluirRelUser(user);
			lPDAO.excluirLocalRelUser(user);
			hDAO.excluirHistUser(user);
			pDAO.excluirPersonagemUser(user);
			lDAO.excluirLocalUser(user);
			aDAO.excluirNotaUser(user);
			uDAO.excluirUser(user);
			return false;
		} else {
			return true;
		}
	}

}

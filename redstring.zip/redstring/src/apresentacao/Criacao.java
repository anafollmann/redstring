package apresentacao;

import java.time.LocalDate;
import java.util.Scanner;

import model.Historia;
import model.Personagem;
import model.Usuario;
import model.PersoPerso;
import model.LocalPersona;
import persistencia.HistoriaDAO;
import persistencia.PersonagemDAO;
import persistencia.PersoPersoDAO;
import persistencia.LocalPersonaDAO;
import persistencia.LocalizacaoDAO;
import model.Localizacao;

public class Criacao {
	Scanner kb = new Scanner(System.in);
	int entrada = 0;

	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	PersoPersoDAO relDAO = new PersoPersoDAO();
	HistoriaDAO hDAO = new HistoriaDAO();
	PersonagemDAO pDAO = new PersonagemDAO();
	LocalPersonaDAO lPDAO = new LocalPersonaDAO();
	Historia hist = new Historia();
	PersoPerso perRel = new PersoPerso();
	LocalPersona locPer = new LocalPersona();
	Localizacao local = new Localizacao();

	public Historia criarHist(Usuario user) {
		System.out.println("\n-> Criar uma nova história.");

		hist.setUsuario(user);

		boolean create = false;
		while (!create) {
			System.out.println("\nTítulo da história:");
			kb.nextLine();
			hist.setTituloHist(kb.nextLine());

			hist.setDataHist(LocalDate.now());

			System.out.println("Descrição da história:");

			hist.setDescHist(kb.nextLine());

			System.out.println("Confirme as informações: \n" + "Título: " + hist.getTituloHist() + "\nDescrição: "
					+ hist.getDescHist());

			System.out.println("1. Confirmar informações. \n2. Editar informações");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				hist = hDAO.adicionarHist(hist);
				if (hist.getIdHistoria() == 0) {
					System.out.println("Aconteceu na criação, por favor tente novamente.");
				} else {
					create = true;
				}
			}
		}
		return hist;
	}

	public Personagem criarPerso(Usuario user) {
		Personagem personagem = new Personagem();

		System.out.println("\n-> Criar um novo personagem.");

		personagem.setUsuario(user);
		personagem.setHistoria(null);

		boolean create = false;
		while (!create) {
			System.out.println("\nNome do personagem:");
			personagem.setNomePerso(kb.nextLine());

			System.out.println("Aparência do personagem:");
			personagem.setAparenciaPerso(kb.nextLine());

			System.out.println("Descrição do personagem:");
			personagem.setDescPerso(kb.nextLine());

			System.out.println("Deseja relacionar esse personagem a uma história? \n1. Sim.\n2. Não.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				System.out.println("Com que história deseja relacionar? ");
				kb.nextLine();
				hist = hDAO.buscaTitulo(kb.nextLine());

				if (hist == null || hist.getUsuario().getIdUsuario() != user.getIdUsuario()) {
					System.out.println("Essa história não existe.");
				} else {
					personagem.setHistoria(hist);
				}
			} else {
				personagem.setHistoria(null);
			}

			System.out.println("Confirme as informações: \n" + "Nome: " + personagem.getNomePerso() + "\nAparência: "
					+ personagem.getAparenciaPerso() + "\nDescrição: " + personagem.getDescPerso());
			if (personagem.getHistoria() != null) {
				System.out.println("História: " + hist.getTituloHist());
			}

			personagem = pDAO.adicionarPerso(personagem);
			if (personagem.getIdPerso() == 0) {
				System.out.println("Algo errado aconteceu na criação, por favor tente novamente.");
				break;
			}

			System.out.println("-> Você deseja relacionar esse personagem a alguma criação?");

			System.out.println("1. Sim.\n2. Não.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) { // relacionamento
				System.out.println("-> Relacionamento");

				boolean relate = true;
				while (relate) {
					System.out.println("1. Personagem.\n2. Local.");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada < 1 || entrada > 3) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					switch (entrada) {
					case 1: // personagem RELACAO DE PERSONAGEM COM PERSONAGEM // opcao de mais de um
						perRel.setPerso1(personagem);

						System.out.println("Com que personagem deseja relacionar?");
						kb.nextLine();
						perRel.setPerso2(pDAO.buscaNome(kb.nextLine()));

						if (perRel.getPerso2() == null
								|| perRel.getPerso2().getUsuario().getIdUsuario() != user.getIdUsuario()) {
							System.out.println("Esse personagem não existe.");
						} else {
							System.out.println("Qual o título de sua relação?");
							perRel.setRelTitulo(kb.nextLine());

							System.out.println("Confirme: \n" + perRel.getPerso1().getNomePerso() + " e "
									+ perRel.getPerso2().getNomePerso() + ": " + perRel.getRelTitulo());

							relDAO.adicionarPRel(perRel);

						}

						break;
					case 2: // local RELACAO LOCAL COM PERSONAGEM
						locPer.setPersonagem(personagem);

						System.out.println("Com que lugar deseja relacionar?");
						kb.nextLine();
						locPer.setLocal(lDAO.buscaPorNome(kb.nextLine()));

						if (locPer.getLocal() == null
								|| locPer.getLocal().getUsuario().getIdUsuario() != user.getIdUsuario()) {
							System.out.println("Esse local não existe.");
						} else {
							System.out.println("Confirme: \n" + locPer.getLocal().getTituloLocal() + " e "
									+ locPer.getPersonagem().getNomePerso());

							lPDAO.adicionarLocalRel(locPer);

						}
						break;
					}// termina switch entre loc e per

					System.out.println("Deseja relacionar personagem com outra criação?\n1. Sim.\n2. Não.");
					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 2) {
						relate = false;
						create = true;
					}
				}
			} else { // se não quiser relacionar
				create = true;
			}
		} // termina while de criar personagem

		return personagem;
	}

	public Localizacao criarLocal(Usuario user) {
		System.out.println("\n-> Criar um local");

		local.setUsuario(user);

		boolean create = false;
		while (!create) {
			System.out.println("Qual o nome do local?");
			kb.nextLine();
			local.setTituloLocal(kb.nextLine());

			System.out.println("Dê uma descrição do local.");
			local.setDescLocal(kb.nextLine());

			System.out.println("Deseja relacionar esse local a uma história? \n1. Sim.\n2. Não.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				System.out.println("Com que história deseja relacionar? ");
				kb.nextLine();
				hist = hDAO.buscaTitulo(kb.nextLine());

				if (hist == null || hist.getUsuario().getIdUsuario() != user.getIdUsuario()) {
					System.out.println("Essa história não existe.");
				} else {
					local.setHistoria(hist);
				}
			} else {
				local.setHistoria(null);
			}

			System.out.println("Confirme as informações: \n" + "Nome: " + local.getTituloLocal() + "\nDescrição: "
					+ local.getDescLocal());
			if (local.getHistoria() != null) {
				System.out.println("História: " + hist.getTituloHist());
			}

			local = lDAO.adicionarLocal(local);
			if (local.getIdLocal() == 0) {
				System.out.println("Algo errado aconteceu na criação, por favor tente novamente.");
				break;
			}

			System.out.println("-> Você deseja relacionar esse local a algum personagem?");

			System.out.println("1. Sim.\n2. Não.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				locPer.setLocal(local);

				boolean relate = true;
				while (relate) {
					System.out.println("Com que personagem deseja relacionar?");
					kb.nextLine();
					locPer.setPersonagem(pDAO.buscaNome(kb.nextLine()));

					if (locPer.getPersonagem() == null
							|| locPer.getLocal().getUsuario().getIdUsuario() != user.getIdUsuario()) {
						System.out.println("Esse personagem não existe.");
					} else {
						System.out.println("Confirme: \n" + locPer.getLocal().getTituloLocal() + " e "
								+ locPer.getPersonagem().getNomePerso());

						lPDAO.adicionarLocalRel(locPer);
					}

					System.out.println("-> Você deseja relacionar esse local a outro personagem");

					System.out.println("1. Sim.\n2. Não.");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}
					
					if (entrada == 2) {
						create = true;
						relate = false;
					}
				}
			} else {
				create = true;
			}

		} // termina while de create

		return local;
	}

}

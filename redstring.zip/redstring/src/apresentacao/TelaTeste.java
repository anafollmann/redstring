package apresentacao;

import java.time.LocalDate;

import model.Localizacao;
import model.LocalPersona;
import model.Personagem;
import model.PersoPerso;
import model.Anotacao;
import model.Usuario;
import model.Historia;

import persistencia.HistoriaDAO;
import persistencia.PersonagemDAO;
import persistencia.UsuarioDAO;
import persistencia.LocalizacaoDAO;
import persistencia.AnotacaoDAO;
import persistencia.PersoPersoDAO;
import persistencia.LocalPersonaDAO;

public class TelaTeste {
	public static void main(String[] args) {
		Usuario usuario = new Usuario(2, "Lina", "acfollmann@gmail.com", "redstring", null, null, null, null);
		UsuarioDAO uDAO = new UsuarioDAO();
		HistoriaDAO hDAO = new HistoriaDAO();
		PersonagemDAO pDAO = new PersonagemDAO();
		LocalizacaoDAO lDAO = new LocalizacaoDAO();
		AnotacaoDAO aDAO = new AnotacaoDAO();
		PersoPersoDAO relDAO = new PersoPersoDAO();
		
		Historia historia = new Historia(3, "The Mandela Catalogue", LocalDate.now(), "Who have i been praying to?", usuario, null, null, null);
		
		Personagem personagem = new Personagem(1, "Gabriel", "Gods messenger, an imposter", "A twisted smile", usuario, historia, null, null, null);
		
	}

}

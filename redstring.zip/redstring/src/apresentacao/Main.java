package apresentacao;

import java.util.Scanner;
import model.Usuario;

public class Main {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);

		Usuario user = new Usuario();
		Perfil perfil = new Perfil();
		Criacao criar = new Criacao();
		Escrita escrita = new Escrita();
		Acesso acesso = new Acesso();
		Edicao editar = new Edicao();
		Apagar apagar = new Apagar();

		// CADASTRO E LOGIN

		int entrada = 0;
		String texto = "";
		boolean accountExist = false;

		System.out.println(
				"1. Não tenho uma conta, desejo fazer cadastro. \n" + "2. Já tenho uma conta, desejo fazer login");

		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) { // CADASTRO working
			user = perfil.cadastrar();
			accountExist = true;

		} else if (entrada == 2) { // LOGIN workingg
			user = perfil.login();
			accountExist = true;

		}

		System.out.println("\nSeja bem-vindo/a a REDSTRING, " + user.getUsername() + "! \n");

		boolean run = true;
		while (run) {
			System.out.println("1. Acessar meu perfil. \n" + "2. Nova criação. \n" + "3. Escrever uma anotação.\n"
					+ "4. Acessar minhas criações. \n" + "5. Editar uma criação \n" + "6. Apagar uma criação. \n"
					+ "7. Sair do programa.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada < 1 || entrada > 7) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 7) {
				System.out.println("Tem certeza que deseja sair? \n1. Sim. \n2. Não, quero permanecer.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada != 1 && entrada != 2) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}
				if (entrada == 1) {
					break;
				} else {
					entrada = 0;
				}
			}

			switch (entrada) {
			case 1: // acessar perfil
				System.out.println("\n-> Seu perfil");

				System.out.println("Username: " + user.getUsername() + "\nEmail: " + user.getEmail());

				boolean change = true;
				while (change) {
					System.out.println("\n1. Editar conta. \n2. Apagar conta. \n3. Voltar ao menu.");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada < 1 || entrada > 3) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 3) {
						break;
					}

					System.out.println("Digite sua senha:");
					texto = kb.next();

					if (entrada == 1 && texto.equals(user.getSenha())) { // editar

						perfil.editar(user);

						change = false;

					} else if (entrada == 2 && texto.equals(user.getSenha())) { // excluir

						change = false;
						accountExist = perfil.excluir(user);

					} else if (!texto.equals(user.getSenha())) { // se a senha for incorreta
						System.out.println("Senha incorreta.");
					}
				}

				break;
			case 2: // criação
				System.out.println("\n-> Nova criação.\n");

				System.out.println(
						"O que você deseja criar? \n1. Uma história. \n2. Um personagem. \n3. Um local. \n4. Voltar ao menu inicial.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada < 1 || entrada > 4) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 4) { // volta ao menu inicial
					break;
				}

				if (entrada == 1) { // hist

					criar.criarHist(user);

				} else if (entrada == 2) { // perso

					criar.criarPerso(user);

				} else if (entrada == 3) { // criar local

					criar.criarLocal(user);

				}

				break;

			case 3: // escrever
				System.out.println("\n-> Nova anotação.");

				System.out.println("A anotação é relacionada a:");
				System.out.println("1. Uma história.\n2. Um personagem.\n3. Um local. \n4. Voltar ao menu inicial.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada < 1 || entrada > 4) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 4) {
					break;
				}

				switch (entrada) {
				case 1: // hist note

					escrita.notaHist(user);

					break;

				case 2: // perso note

					escrita.notaPerso(user);

					break;

				case 3: // local note

					escrita.notaLocal(user);

					break;
				}

				break;
			case 4: // acessar
				System.out.println("\n-> Acessar suas criações:");
				System.out.println(
						"1. Histórias. \n2. Personagens. \n3. Locais. \n4. Anotações. \n5. Voltar ao menu inicial.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada < 1 || entrada > 5) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 5) {
					break;
				}

				switch (entrada) {
				case 1: // busca por uma historia especifica + anotacoes e busca por todas

					System.out.println("1. Ver todas. \n2. Buscar por nome");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 1) { // todas

						acesso.todasHist(user);

					} else { // busca

						acesso.buscaNomeHist(user);

					}

					break;

				case 2: // busca por personagem especifico + anotacoes e busca por todas

					System.out.println("1. Ver todos. \n2. Buscar por nome");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 1) { // todos

						acesso.todosPerso(user);

					} else { // busca

						acesso.buscaNomePerso(user);

					}

					break;

				case 3: // busca por locais especificos + busca por todas.

					System.out.println("1. Ver todos. \n2. Buscar por nome");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 1) { // todos

						acesso.todosLocais(user);

					} else { // busca

						acesso.buscaNomeLocal(user);

					}

					break;

				case 4:
					System.out.println("1. Ver todas. \n2. Buscar por nome");

					entrada = 0;
					while (entrada == 0) {
						entrada = kb.nextInt();
						if (entrada != 1 && entrada != 2) {
							System.out.println("Resposta inválida");
							entrada = 0;
						}
					}

					if (entrada == 1) { // todos

						acesso.todasNotas(user);

					} else { // busca

						acesso.buscaNomeNota(user);

					}

					break;
				}
				break;

			case 5: // editar

				System.out.println("\n-> Edição");
				System.out.println(
						"O que você deseja editar? \n1. História. \n2. Personagem. \n3. Local. \n4. Anotação \n5. Voltar para o menu.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada < 1 || entrada > 5) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 5) {
					break;
				}

				switch (entrada) {
				case 1: // editar hist

					editar.editarHist(user);

					break;

				case 2: // editar perso

					editar.editarPerso(user);

					break;

				case 3: // editar local

					editar.editarLocal(user);

					break;

				case 4:

					editar.editarNota(user);
					break;
				}

				break;

			case 6: // apagar

				System.out.println("\n-> Apagar");
				System.out.println(
						"O que você deseja apagar? \n1. História. \n2. Personagem. \n3. Local. \n4. Anotação \n5. Voltar para o menu.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada < 1 || entrada > 5) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 5) {
					break;
				}

				switch (entrada) {
				case 1: // apagar hist

					apagar.apagarHist(user);

					break;

				case 2: // apagar perso

					apagar.apagarPerso(user);

					break;

				case 3: // apagarr local

					apagar.apagarLocal(user);

					break;

				case 4: // apagar nota

					apagar.apagarNotas(user);

					break;
				}

				break;
			}
			if (!accountExist) { // se aconta foi deletada
				System.out.println("A conta " + user.getUsername() + " não existe mais.");
				break;
			}

		}
		kb.close();
	}
}

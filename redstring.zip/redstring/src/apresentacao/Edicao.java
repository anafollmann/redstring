package apresentacao;

import java.util.Scanner;

import model.Anotacao;
import model.Historia;
import model.Usuario;
import model.Localizacao;
import persistencia.AnotacaoDAO;
import persistencia.HistoriaDAO;
import persistencia.LocalizacaoDAO;
import persistencia.PersonagemDAO;
import model.Personagem;

public class Edicao {

	Scanner kb = new Scanner(System.in);
	HistoriaDAO hDAO = new HistoriaDAO();
	Historia hist = new Historia();
	PersonagemDAO pDAO = new PersonagemDAO();
	Personagem personagem = new Personagem();
	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	Localizacao local = new Localizacao();
	AnotacaoDAO aDAO = new AnotacaoDAO();
	Anotacao nota = new Anotacao();
	
	int entrada;

	public void editarHist(Usuario user) {
		System.out.println("-> Editar história. \nQue história deseja editar?");
		hist = hDAO.buscaTitulo(kb.nextLine());

		if (hist == null || user.getIdUsuario() != hist.getUsuario().getIdUsuario()) {
			System.out.println("Nenhuma história com esse nome existe.");
		} else {

			System.out.println(
					"\n" + hist.getTituloHist() + "\n" + hist.getDataHist() + "\n" + hist.getDescHist() + "\n");

			System.out.println("Editar título:");
			hist.setTituloHist(kb.nextLine());

			System.out.println("Editar descrição:");
			hist.setDescHist(kb.nextLine());

			System.out.println(
					"\n" + hist.getTituloHist() + "\n" + hist.getDataHist() + "\n" + hist.getDescHist() + "\n");

			System.out.println("Confirmar? \n1. Sim. \n2. Não");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				hDAO.editarHist(hist);
			}
		}
	}

	public void editarPerso(Usuario user) {
		System.out.println("-> Editar personagem. \nQue personagem deseja editar?");
		personagem = pDAO.buscaNome(kb.nextLine());

		if (personagem == null || user.getIdUsuario() != personagem.getUsuario().getIdUsuario()) {
			System.out.println("Nenhum personagem com esse nome existe.");
		} else {

			System.out.println("\n" + personagem.getNomePerso() + "\n" + personagem.getAparenciaPerso() + "\n"
					+ personagem.getDescPerso() + "\n");

			System.out.println("Editar nome:");
			personagem.setNomePerso(kb.nextLine());
			
			System.out.println("Editar aparência:");
			personagem.setAparenciaPerso(kb.nextLine());
			
			System.out.println("Editar descrição:");
			personagem.setDescPerso(kb.nextLine());
			
			System.out.println("\n" + personagem.getNomePerso() + "\n" + personagem.getAparenciaPerso() + "\n"
					+ personagem.getDescPerso() + "\n");

			System.out.println("Confirmar? \n1. Sim. \n2. Não");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				pDAO.editarPersonagem(personagem);
			}
		}
	}

	
	public void editarLocal(Usuario user) {
		System.out.println("-> Editar Local. \nQue local deseja editar?");
		local = lDAO.buscaPorNome(kb.nextLine());

		if (local == null || user.getIdUsuario() != local.getUsuario().getIdUsuario()) {
			System.out.println("Nenhum local com esse nome existe.");
		} else {

			System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());

			System.out.println("Editar nome:");
			local.setTituloLocal(kb.nextLine());
			
			System.out.println("Editar descrição:");
			local.setDescLocal(kb.nextLine());
			
			System.out.println("\n" + local.getTituloLocal() + "\n" + local.getDescLocal());

			System.out.println("Confirmar? \n1. Sim. \n2. Não");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				lDAO.editarLocal(local);
			}
		}
	}
	
	public void editarNota(Usuario user) {
		System.out.println("-> Editar Anotação. \nQue anotação deseja editar?");
		Anotacao nota = aDAO.buscarNomeNota(kb.nextLine());

		if (nota == null || user.getIdUsuario() != nota.getUsuario().getIdUsuario()) {
			System.out.println("Nenhuma anotação com esse nome existe.");
		} else {
			System.out.println("\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo());

			System.out.println("Editar título:");
			nota.setTituloNota(kb.nextLine());
			
			System.out.println("Editar conteúdo:");
			nota.setConteudo(kb.nextLine());
			
			System.out.println("\n" + nota.getTituloNota() + "\n" + nota.getDataNota() + "\n" + nota.getConteudo());

			System.out.println("Confirmar? \n1. Sim. \n2. Não");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				aDAO.editarNota(nota);
			}
		}
	}


}

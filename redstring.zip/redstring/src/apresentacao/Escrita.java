package apresentacao;

import java.time.LocalDate;
import java.util.Scanner;
import model.Anotacao;
import model.Usuario;
import model.Historia;
import model.Personagem;
import model.Localizacao;
import persistencia.LocalizacaoDAO;
import persistencia.AnotacaoDAO;
import persistencia.HistoriaDAO;
import persistencia.PersonagemDAO;

public class Escrita {
	Scanner kb = new Scanner(System.in);
	int entrada = 0;

	Personagem perso = new Personagem();
	Anotacao nota = new Anotacao();
	Localizacao local = new Localizacao();
	AnotacaoDAO aDAO = new AnotacaoDAO();
	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	PersonagemDAO pDAO = new PersonagemDAO();
	HistoriaDAO hDAO = new HistoriaDAO();
	Historia hist = new Historia();

	public Anotacao notaHist(Usuario user) {
		nota.setDataNota(LocalDate.now());

		nota.setUsuario(user);

		boolean relate = true;
		while (relate) {
			System.out.println("Com que história deseja relacionar essa anotação?");
			nota.setHistoria(hDAO.buscaTitulo(kb.nextLine()));

			if (nota.getHistoria() == null || nota.getHistoria().getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Essa história não existe.");
			} else {
				relate = false;
			}
		}

		System.out.println("Dê um título a essa anotação:");
		nota.setTituloNota(kb.nextLine());

		System.out.println("Escreva sua anotação:");
		nota.setConteudo(kb.nextLine());

		System.out.println("\nConfirme: \nTítulo: " + nota.getTituloNota() + "\nData: " + nota.getDataNota() + "\n"
				+ nota.getConteudo());

		System.out.println("\n1. Confirmar. \n2. Excluir.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) {
			nota = aDAO.adicionarNota(nota, 1);
		}

		return nota;
	}

	public Anotacao notaPerso(Usuario user) {
		nota.setDataNota(LocalDate.now());

		nota.setUsuario(user);

		boolean relate = true;
		while (relate) {
			System.out.println("Com que personagem deseja relacionar essa anotação?");
			nota.setPersonagem(pDAO.buscaNome(kb.nextLine()));

			if (nota.getPersonagem() == null
					|| nota.getPersonagem().getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Esse personagem não existe.");
			} else {
				relate = false;
			}
		}

		System.out.println("Dê um título a essa anotação:");
		nota.setTituloNota(kb.nextLine());

		System.out.println("Escreva sua anotação:");
		nota.setConteudo(kb.nextLine());

		System.out.println("\nConfirme: \nTítulo: " + nota.getTituloNota() + "\nData: " + nota.getDataNota() + "\n"
				+ nota.getConteudo());

		System.out.println("\n1. Confirmar. \n2. Excluir.");

		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) {
			nota = aDAO.adicionarNota(nota, 2);
		}

		return nota;
	}

	public Anotacao notaLocal(Usuario user) {
		nota.setDataNota(LocalDate.now());

		nota.setUsuario(user);

		boolean relate = true;
		while (relate) {
			System.out.println("Com que local deseja relacionar essa anotação?");
			nota.setLocal(lDAO.buscaPorNome((kb.nextLine())));

			if (nota.getLocal() == null || nota.getLocal().getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Esse local não existe.");
			} else {
				relate = false;
			}
		}

		System.out.println("Dê um título a essa anotação:");
		nota.setTituloNota(kb.nextLine());

		System.out.println("Escreva sua anotação:");
		nota.setConteudo(kb.nextLine());

		System.out.println("\nConfirme: \nTítulo: " + nota.getTituloNota() + "\nData: " + nota.getDataNota() + "\n"
				+ nota.getConteudo());

		System.out.println("\n1. Confirmar. \n2. Excluir.");

		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) {
			nota = aDAO.adicionarNota(nota, 3);
		}

		return nota;
	}
}

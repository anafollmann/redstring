package apresentacao;

import java.util.Scanner;

import model.Anotacao;
import model.Historia;
import model.Localizacao;
import model.Personagem;
import model.Usuario;
import persistencia.AnotacaoDAO;
import persistencia.HistoriaDAO;
import persistencia.LocalizacaoDAO;
import persistencia.PersonagemDAO;

public class Apagar {

	Scanner kb = new Scanner(System.in);
	HistoriaDAO hDAO = new HistoriaDAO();
	Historia hist = new Historia();
	PersonagemDAO pDAO = new PersonagemDAO();
	Personagem personagem = new Personagem();
	LocalizacaoDAO lDAO = new LocalizacaoDAO();
	Localizacao local = new Localizacao();
	AnotacaoDAO aDAO = new AnotacaoDAO();
	Anotacao nota = new Anotacao();

	int entrada;

	public void apagarHist(Usuario user) {
		System.out.println("1. Apagar uma. \n2. Apagar todas.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) { // uma
			System.out.println("Qual história deseja excluir?");
			kb.nextLine();
			Historia hist = hDAO.buscaTitulo(kb.nextLine());

			if (hist == null || hist.getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Essa história não existe.");
			} else {

				System.out.println(
						"Você tem certeza? Depois de apagada não pode ser recuperada. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada != 1 && entrada != 2) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 1) {
					hDAO.excluirHist(hist);
					System.out.println(hist.getTituloHist() + " não existe mais");
				}
			}

		} else { // todas

			System.out.println(
					"Você tem certeza? Depois de apagadas não podem ser recuperadas. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				hDAO.excluirHistUser(user);
				System.out.println("Suas histórias não existem mais");
			}

		}

	}
	
	public void apagarPerso(Usuario user) {
		System.out.println("1. Apagar um. \n2. Apagar todos.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) { // uma
			System.out.println("Qual personagem deseja excluir?");
			kb.nextLine();
			Personagem personagem = pDAO.buscaNome(kb.nextLine());
			
			if (personagem == null || personagem.getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Esse personagem não existe.");
			} else {

				System.out.println(
						"Você tem certeza? Depois de apagado não pode ser recuperada. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada != 1 && entrada != 2) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 1) {
					pDAO.excluirPersonagem(personagem);
					System.out.println(personagem.getNomePerso() + " não existe mais");
				}
			}

		} else { // todas
			
			System.out.println(
					"Você tem certeza? Depois de apagados não podem ser recuperados. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				pDAO.excluirPersonagemUser(user);
				System.out.println("Seus personagens não existem mais");
			}

		}

	}

	public void apagarLocal(Usuario user) {
		System.out.println("1. Apagar um. \n2. Apagar todos.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) { // uma
			System.out.println("Qual local deseja excluir?");
			kb.nextLine();
			Localizacao local = lDAO.buscaPorNome(kb.next());
			
			if (local == null || local.getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Essa local não existe.");
			} else {

				System.out.println(
						"Você tem certeza? Depois de apagado não pode ser recuperado. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada != 1 && entrada != 2) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 1) {
					lDAO.excluirLocal(local);
					System.out.println(local.getTituloLocal() + " não existe mais");
				}
			}

		} else { // todas
			
			System.out.println(
					"Você tem certeza? Depois de apagados não podem ser recuperados. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				lDAO.excluirLocalUser(user);
				System.out.println("Seus locais não existem mais");
			}

		}

	}

	public void apagarNotas(Usuario user) {
		System.out.println("1. Apagar uma. \n2. Apagar todas.");

		entrada = 0;
		while (entrada == 0) {
			entrada = kb.nextInt();
			if (entrada != 1 && entrada != 2) {
				System.out.println("Resposta inválida");
				entrada = 0;
			}
		}

		if (entrada == 1) { // uma
			System.out.println("Qual anotação deseja excluir?");
			kb.nextLine();
			Anotacao nota = aDAO.buscarNomeNota(kb.nextLine());
			
			if (nota == null || nota.getUsuario().getIdUsuario() != user.getIdUsuario()) {
				System.out.println("Essa anotação não existe.");
			} else {

				System.out.println(
						"Você tem certeza? Depois de apagada não pode ser recuperada. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

				entrada = 0;
				while (entrada == 0) {
					entrada = kb.nextInt();
					if (entrada != 1 && entrada != 2) {
						System.out.println("Resposta inválida");
						entrada = 0;
					}
				}

				if (entrada == 1) {
					aDAO.excluirNota(nota);
					System.out.println(nota.getTituloNota() + " não existe mais");
				}
			}

		} else { // todas

			System.out.println(
					"Você tem certeza? Depois de apagadas não podem ser recuperadas. \n1. Sim, tenho certeza. \n2. Não, não quero apagar.");

			entrada = 0;
			while (entrada == 0) {
				entrada = kb.nextInt();
				if (entrada != 1 && entrada != 2) {
					System.out.println("Resposta inválida");
					entrada = 0;
				}
			}

			if (entrada == 1) {
				aDAO.excluirNotaUser(user);
				System.out.println("Suas anotações não existem mais");
			}

		}

	}


}

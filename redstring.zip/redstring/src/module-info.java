/**
 * 
 */
/**
 * @author Ana
 *
 */
module redstring {
	requires java.sql;
}
package model;

import java.util.ArrayList;

public class Usuario {
	private long idUsuario;
	private String username;
	private String email;
	private String senha;
	ArrayList<Historia> historias;
	ArrayList<Localizacao> locais;
	ArrayList<Personagem> personagens;
	ArrayList<Anotacao> anotacoes;
	
	public Usuario(long idUsuario, String username, String email, String senha, ArrayList<Historia> historias,
			ArrayList<Localizacao> locais, ArrayList<Personagem> personagens, ArrayList<Anotacao> anotacoes) {
		this.idUsuario = idUsuario;
		this.username = username;
		this.email = email;
		this.senha = senha;
		this.historias = historias;
		this.locais = locais;
		this.personagens = personagens;
		this.anotacoes = anotacoes;
	}

	public Usuario() {
		idUsuario = 0;
		username = "";
		email = "";
		senha = "";
		historias = new ArrayList<Historia>();
		locais = new ArrayList<Localizacao>();
		personagens = new ArrayList<Personagem>();
		anotacoes = new ArrayList<Anotacao>();
	}

	public long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public ArrayList<Historia> getHistorias() {
		return historias;
	}

	public void setHistorias(ArrayList<Historia> historias) {
		this.historias = historias;
	}

	public ArrayList<Localizacao> getLocais() {
		return locais;
	}

	public void setLocais(ArrayList<Localizacao> locais) {
		this.locais = locais;
	}

	public ArrayList<Personagem> getPersonagens() {
		return personagens;
	}

	public void setPersonagens(ArrayList<Personagem> personagens) {
		this.personagens = personagens;
	}

	public ArrayList<Anotacao> getAnotacoes() {
		return anotacoes;
	}

	public void setAnotacoes(ArrayList<Anotacao> anotacoes) {
		this.anotacoes = anotacoes;
	}

	@Override
	public String toString() {
		return "idUsuario = " + idUsuario + ", username = " + username + ", email = " + email + ", senha = " + senha
				+ ", historias = " + historias + ", locais = " + locais + ", personagens = " + personagens
				+ ", anotacoes = " + anotacoes;
	}

}

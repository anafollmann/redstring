package model;
import java.time.LocalDate;
import java.util.ArrayList;

public class Historia {
	private long idHistoria;
	private String tituloHist;
	private LocalDate dataHist;
	private String descHist;
	private Usuario usuario;
	ArrayList<Localizacao> locais = new ArrayList<Localizacao>();
	ArrayList<Personagem> personagens = new ArrayList<Personagem>();
	ArrayList<Anotacao> anotacoes = new ArrayList<Anotacao>();
	
	public Historia() {
		idHistoria = 0;
		tituloHist = "";
		dataHist = LocalDate.now();
		descHist = "";
		usuario = new Usuario();
		locais = new ArrayList<Localizacao>();
		personagens = new ArrayList<Personagem>();
		anotacoes = new ArrayList<Anotacao>();
	}

	public Historia(long idHistoria, String tituloHist, LocalDate dataHist, String descHist, Usuario usuario,
			ArrayList<Localizacao> locais, ArrayList<Personagem> personagens, ArrayList<Anotacao> anotacoes) {
		this.idHistoria = idHistoria;
		this.tituloHist = tituloHist;
		this.dataHist = dataHist;
		this.descHist = descHist;
		this.usuario = usuario;
		this.locais = locais;
		this.personagens = personagens;
		this.anotacoes = anotacoes;
	}

	public long getIdHistoria() {
		return idHistoria;
	}

	public void setIdHistoria(long idHistoria) {
		this.idHistoria = idHistoria;
	}

	public String getTituloHist() {
		return tituloHist;
	}

	public void setTituloHist(String tituloHist) {
		this.tituloHist = tituloHist;
	}

	public LocalDate getDataHist() {
		return dataHist;
	}

	public void setDataHist(LocalDate dataHist) {
		this.dataHist = dataHist;
	}

	public String getDescHist() {
		return descHist;
	}

	public void setDescHist(String descHist) {
		this.descHist = descHist;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public ArrayList<Localizacao> getLocais() {
		return locais;
	}

	public void setLocais(ArrayList<Localizacao> locais) {
		this.locais = locais;
	}

	public ArrayList<Personagem> getPersonagens() {
		return personagens;
	}

	public void setPersonagens(ArrayList<Personagem> personagens) {
		this.personagens = personagens;
	}

	public ArrayList<Anotacao> getAnotacoes() {
		return anotacoes;
	}

	public void setAnotacoes(ArrayList<Anotacao> anotacoes) {
		this.anotacoes = anotacoes;
	}

	@Override
	public String toString() {
		return "idHistoria = " + idHistoria + ", tituloHist = " + tituloHist + ", dataHist = " + dataHist
				+ ", descHist = " + descHist + ", usuario = " + usuario + ", locais = " + locais + ", personagens = "
				+ personagens + ", anotacoes = " + anotacoes;
	}

}

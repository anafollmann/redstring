package model;

public class LocalPersona {
	private long idLocalPersona;
	private Personagem personagem;
	private Localizacao local;
	
	
	
	public LocalPersona(long idLocalPersona, Personagem personagem, Localizacao local) {
		this.idLocalPersona = idLocalPersona;
		this.personagem = personagem;
		this.local = local;
	}

	public LocalPersona() {
		idLocalPersona = 0;
		personagem = new Personagem();
		local = new Localizacao();
	}

	public long getIdLocalPersona() {
		return idLocalPersona;
	}

	public void setIdLocalPersona(long idLocalPersona) {
		this.idLocalPersona = idLocalPersona;
	}

	public Personagem getPersonagem() {
		return personagem;
	}

	public void setPersonagem(Personagem personagem) {
		this.personagem = personagem;
	}

	public Localizacao getLocal() {
		return local;
	}

	public void setLocal(Localizacao local) {
		this.local = local;
	}

	@Override
	public String toString() {
		return "idLocalPersona = " + idLocalPersona + ", personagem = " + personagem + ", local = " + local;
	}

}

package model;

public class PersoPerso {
	private long idPersoPerso;
	private String relTitulo;
	private Personagem perso1;
	private Personagem perso2;
	
	public PersoPerso() {
		idPersoPerso = 0;
		perso1 = new Personagem();
		perso2 = new Personagem();
	}

	public PersoPerso(long idPersoPerso, String relTitulo, Personagem perso1, Personagem perso2) {
		this.idPersoPerso = idPersoPerso;
		this.relTitulo = relTitulo;
		this.perso1 = perso1;
		this.perso2 = perso2;
	}

	public long getIdPersoPerso() {
		return idPersoPerso;
	}

	public void setIdPersoPerso(long idPersoPerso) {
		this.idPersoPerso = idPersoPerso;
	}
	
	public String getRelTitulo() {
		return relTitulo;
	}

	public void setRelTitulo(String relTitulo) {
		this.relTitulo = relTitulo;
	}

	public Personagem getPerso1() {
		return perso1;
	}

	public void setPerso1(Personagem perso1) {
		this.perso1 = perso1;
	}

	public Personagem getPerso2() {
		return perso2;
	}

	public void setPerso2(Personagem perso2) {
		this.perso2 = perso2;
	}

	@Override
	public String toString() {
		return "idPersoPerso = " + idPersoPerso + ", perso1 = " + perso1 + ", perso2 = " + perso2;
	}

}

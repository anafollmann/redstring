package model;

import java.time.LocalDate;

public class Anotacao {
	private long idNota;
	private String tituloNota;
	private String conteudo;
	private LocalDate dataNota;
	private Usuario usuario;
	private Historia historia;
	private Localizacao local;
	private Personagem personagem;
	
	public Anotacao(long idNota, String tituloNota, String conteudo, LocalDate dataNota, Usuario usuario,
			Historia historia, Localizacao local, Personagem personagem) {
		this.idNota = idNota;
		this.tituloNota = tituloNota;
		this.conteudo = conteudo;
		this.dataNota = dataNota;
		this.usuario = usuario;
		this.historia = historia;
		this.local = local;
		this.personagem = personagem;
	}

	public Anotacao() {
		idNota = 0;
		tituloNota = "";
		conteudo = "";
		dataNota = LocalDate.now();
		usuario = new Usuario();
		historia = new Historia();
		local = new Localizacao();
		personagem = new Personagem();
	}

	public long getIdNota() {
		return idNota;
	}

	public void setIdNota(long idNota) {
		this.idNota = idNota;
	}

	public String getTituloNota() {
		return tituloNota;
	}

	public void setTituloNota(String tituloNota) {
		this.tituloNota = tituloNota;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public LocalDate getDataNota() {
		return dataNota;
	}

	public void setDataNota(LocalDate dataNota) {
		this.dataNota = dataNota;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Historia getHistoria() {
		return historia;
	}

	public void setHistoria(Historia historia) {
		this.historia = historia;
	}

	public Localizacao getLocal() {
		return local;
	}

	public void setLocal(Localizacao local) {
		this.local = local;
	}

	public Personagem getPersonagem() {
		return personagem;
	}

	public void setPersonagem(Personagem personagem) {
		this.personagem = personagem;
	}

	@Override
	public String toString() {
		return "idNota = " + idNota + ", tituloNota = " + tituloNota + ", conteudo = " + conteudo + ", dataNota = "
				+ dataNota + ", usuario = " + usuario + ", historia = " + historia + ", local = " + local
				+ ", personagem = " + personagem;
	}
	
}

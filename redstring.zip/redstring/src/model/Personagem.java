package model;

import java.util.ArrayList;

public class Personagem {
	private long idPerso;
	private String nomePerso;
	private String descPerso;
	private String aparenciaPerso;
	private Usuario usuario;
	private Historia historia;
	ArrayList<LocalPersona> localPersona;
	ArrayList<PersoPerso> persoPerso;
	ArrayList<Anotacao> anotacoes;

	public Personagem() {
		idPerso = 0;
		nomePerso = "";
		descPerso = "";
		aparenciaPerso = "";
		usuario = new Usuario();
		historia = new Historia();
		localPersona = new ArrayList<LocalPersona>();
		persoPerso = new ArrayList<PersoPerso>();
		anotacoes = new ArrayList<Anotacao>();
	}

	public Personagem(long idPerso, String nomePerso, String descPerso, String aparenciaPerso, Usuario usuario,
			Historia historia, ArrayList<LocalPersona> localPersona, ArrayList<PersoPerso> persoPerso,
			ArrayList<Anotacao> anotacoes) {
		this.idPerso = idPerso;
		this.nomePerso = nomePerso;
		this.descPerso = descPerso;
		this.aparenciaPerso = aparenciaPerso;
		this.usuario = usuario;
		this.historia = historia;
		this.localPersona = localPersona;
		this.persoPerso = persoPerso;
		this.anotacoes = anotacoes;
	}

	public long getIdPerso() {
		return idPerso;
	}

	public void setIdPerso(long idPerso) {
		this.idPerso = idPerso;
	}

	public String getNomePerso() {
		return nomePerso;
	}

	public void setNomePerso(String nomePerso) {
		this.nomePerso = nomePerso;
	}

	public String getDescPerso() {
		return descPerso;
	}

	public void setDescPerso(String descPerso) {
		this.descPerso = descPerso;
	}

	public String getAparenciaPerso() {
		return aparenciaPerso;
	}

	public void setAparenciaPerso(String aparenciaPerso) {
		this.aparenciaPerso = aparenciaPerso;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Historia getHistoria() {
		return historia;
	}

	public void setHistoria(Historia historia) {
		this.historia = historia;
	}

	public ArrayList<LocalPersona> getLocalPersona() {
		return localPersona;
	}

	public void setLocalPersona(ArrayList<LocalPersona> localPersona) {
		this.localPersona = localPersona;
	}

	public ArrayList<PersoPerso> getPersoPerso() {
		return persoPerso;
	}

	public void setPersoPerso(ArrayList<PersoPerso> persoPerso) {
		this.persoPerso = persoPerso;
	}

	public ArrayList<Anotacao> getAnotacoes() {
		return anotacoes;
	}

	public void setAnotacoes(ArrayList<Anotacao> anotacoes) {
		this.anotacoes = anotacoes;
	}

	@Override
	public String toString() {
		return "idPerso = " + idPerso + ", nomePerso = " + nomePerso + ", descPerso = " + descPerso
				+ ", aparenciaPerso = " + aparenciaPerso + ", usuario = " + usuario + ", historia = " + historia
				+ ", localPersona = " + localPersona + ", persoPerso = " + persoPerso + ", anotacoes = " + anotacoes;
	}

}

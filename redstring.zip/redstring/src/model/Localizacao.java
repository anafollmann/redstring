package model;

import java.util.ArrayList;

public class Localizacao {
	private long idLocal;
	private String tituloLocal;
	private String descLocal;
	private Usuario usuario;
	private Historia historia;
	ArrayList<LocalPersona> localPersona;
	ArrayList<Anotacao> anotacoes;
	
	public Localizacao(long idLocal, String tituloLocal, String descLocal, Usuario usuario, Historia historia,
			ArrayList<LocalPersona> localPersona, ArrayList<Anotacao> anotacoes) {
		this.idLocal = idLocal;
		this.tituloLocal = tituloLocal;
		this.descLocal = descLocal;
		this.usuario = usuario;
		this.historia = historia;
		this.localPersona = localPersona;
		this.anotacoes = anotacoes;
	}

	public Localizacao() {
		idLocal = 0;
		tituloLocal = "";
		descLocal = "";
		usuario = new Usuario();
		historia = new Historia();
		localPersona = new ArrayList<LocalPersona>();
		anotacoes = new ArrayList<Anotacao>();
	}

	public long getIdLocal() {
		return idLocal;
	}

	public void setIdLocal(long idLocal) {
		this.idLocal = idLocal;
	}

	public String getTituloLocal() {
		return tituloLocal;
	}

	public void setTituloLocal(String tituloLocal) {
		this.tituloLocal = tituloLocal;
	}

	public String getDescLocal() {
		return descLocal;
	}

	public void setDescLocal(String descLocal) {
		this.descLocal = descLocal;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Historia getHistoria() {
		return historia;
	}

	public void setHistoria(Historia historia) {
		this.historia = historia;
	}

	public ArrayList<LocalPersona> getLocalPersona() {
		return localPersona;
	}

	public void setLocalPersona(ArrayList<LocalPersona> localPersona) {
		this.localPersona = localPersona;
	}

	public ArrayList<Anotacao> getAnotacoes() {
		return anotacoes;
	}

	public void setAnotacoes(ArrayList<Anotacao> anotacoes) {
		this.anotacoes = anotacoes;
	}

	@Override
	public String toString() {
		return "idLocal = " + idLocal + ", tituloLocal = " + tituloLocal + ", descLocal = " + descLocal + ", usuario = "
				+ usuario + ", historia = " + historia + ", localPersona = " + localPersona + ", anotacoes = "
				+ anotacoes;
	}
	
	

}
